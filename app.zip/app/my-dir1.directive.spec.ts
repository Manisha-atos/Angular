import { MyDir1Directive } from './my-dir1.directive';

describe('MyDir1Directive', () => {
  it('should create an instance', () => {
    const directive = new MyDir1Directive();
    expect(directive).toBeTruthy();
  });
});
