import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {MyRedDirective} from './MyRedDirective'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BasicComponent } from './basic/basic.component';
import { CardComponent } from './card/card.component';
import { FormsModule } from '@angular/forms';
import { DdemoComponent } from './ddemo/ddemo.component';
import {TechnologyComponent} from './technology/technology.component';
import { MyDir1Directive } from './my-dir1.directive';
import { DirectivedemoComponent } from './directivedemo/directivedemo.component'
@NgModule({
  declarations: [
    AppComponent,
    BasicComponent,
    CardComponent,
    DdemoComponent,
    TechnologyComponent,
    MyDir1Directive,
    MyRedDirective,
    DirectivedemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
