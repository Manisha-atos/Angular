import { Component } from '@angular/core';

@Component({
  selector: 'test-comp',
  templateUrl: './basic.component.html',
  styleUrls: ['./basic.component.css']
})
export class BasicComponent {

}
