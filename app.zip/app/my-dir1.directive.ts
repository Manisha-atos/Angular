import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appMyDir1]'
})
export class MyDir1Directive {

  constructor(el:ElementRef ){
el.nativeElement.style.backgroundColor='yellow';


   }

}
