import { Component,OnInit } from '@angular/core';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit{

public fname:string="<b><i>Manisha</b></i>";
public lname:string="Mane";
public cmp;

  constructor() {
    console.log("const called!!!!");
    this.cmp="Atos"
   
   }
greetUser()
{
//  alert("hello....")
  return "hello"+this.fname;
}
  ngOnInit() {
    this.cmp="Atos Syntel Pvt Ltd";
  }
 public stringUrl=window.location.href;
public num1:number=0;
public num2:number=0;
public res:number=0;
public sum(a:number,b:number)
{
  this.res=a+b;
  return this.res;
}
}
