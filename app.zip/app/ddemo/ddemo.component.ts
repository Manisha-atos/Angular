import { Component } from '@angular/core';

@Component({
  selector: 'app-ddemo',
  templateUrl: './ddemo.component.html',
  styleUrls: ['./ddemo.component.css']
})
export class DdemoComponent {
  topic="Angular "
  tech="Web Based"
  techA=["Java",".Net","Oracle","Big Data"]
  selectedTech:string='Marathi'
  isavailable:boolean=true
}
